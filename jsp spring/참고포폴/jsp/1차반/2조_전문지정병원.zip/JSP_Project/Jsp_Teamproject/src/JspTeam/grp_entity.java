package JspTeam;

public class grp_entity {
	private String cityName;
	private int cityNum;
	private String unitName;
	private int unitTotal;
	
	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public int getCityNum() {
		return cityNum;
	}

	public void setCityNum(int cityNum) {
		this.cityNum = cityNum;
	}
	
	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public int getUnitTotal() {
		return unitTotal;
	}

	public void setUnitTotal(int unitTotal) {
		this.unitTotal = unitTotal;
	}
}
