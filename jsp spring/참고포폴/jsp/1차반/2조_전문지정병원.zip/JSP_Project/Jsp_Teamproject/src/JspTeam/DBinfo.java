package JspTeam;

public interface DBinfo {
	String mysql_class = "com.mysql.cj.jdbc.Driver";
	String mysql_url = "jdbc:mysql://192.168.0.81/jsp_teamproject";
	String mysql_id = "test";
	String mysql_pw = "1234";
	
}
