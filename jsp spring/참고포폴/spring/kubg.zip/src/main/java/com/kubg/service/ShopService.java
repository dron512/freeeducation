package com.kubg.service;

import java.util.List;

import com.kubg.domain.CartListVO;
import com.kubg.domain.CartVO;
import com.kubg.domain.GoodsViewVO;
import com.kubg.domain.OrderDetailVO;
import com.kubg.domain.OrderListVO;
import com.kubg.domain.OrderVO;
import com.kubg.domain.ReplyListVO;
import com.kubg.domain.ReplyVO;

public interface ShopService {

	
	public List<GoodsViewVO> list(int cateCode, int level)  throws Exception;
	
	
	public GoodsViewVO goodsView(int gdsNum) throws Exception;

	
	public void registReply(ReplyVO reply) throws Exception;
	
	
	public List<ReplyListVO> replyList(int gdsNum) throws Exception;
	
	
	public void deleteReply(ReplyVO reply) throws Exception;
	
	
	public String idCheck(int repNum) throws Exception;

	
	public void modifyReply(ReplyVO reply) throws Exception;

	
	public void addCart(CartListVO cart) throws Exception;

	
	public List<CartListVO> cartList(String userId) throws Exception;

	
	public void deleteCart(CartVO cart) throws Exception;

	
	public void orderInfo(OrderVO order) throws Exception;
	
	
	public void orderInfo_Details(OrderDetailVO orderDetail) throws Exception;

	
	public void cartAllDelete(String userId) throws Exception;
	
	
	public List<OrderVO> orderList(OrderVO order) throws Exception;

	
	public List<OrderListVO> orderView(OrderVO order) throws Exception;
} 